// Call the dataTables jQuery plugin
$(document).ready(function() {
  $("#dataTable").DataTable({
    language: {
      url: "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Dutch.json"
    }
  });
});
