$(document).ready(function() {
  showData();
  function showData() {
    $.ajax({
      url: "action.php",
      type: "POST",
      data: { action: "view" },
      success: function(response) {
        $("#showCustomers").html(response);
        $("table").DataTable({
          order: [0, "desc"]
        });
      }
    });
  }

  //data toevoegen request
  $("#toevoegen").click(function(e) {
    if ($("#form-data")[0].checkValidity()) {
      e.preventDefault();
      $.ajax({
        url: "action.php",
        type: "POST",
        data: $("#form-data").serialize() + "&action=toevoegen",
        success: function(response) {
          console.log(response);
          toastr.success("Klant successvol toegevoegd");
          $("#toevoegModal").modal("hide");
          $("#form-data")[0].reset();
          showData();
        }
      });
    }
  });
  //klanten info in editmodal zetten
  $("body").on("click", ".editBtn", function(e) {
    e.preventDefault();
    edit_id = $(this).attr("id");
    $.ajax({
      url: "action.php",
      type: "POST",
      data: { edit_id: edit_id },
      success: function(response) {
        data = JSON.parse(response);
        $("#id").val(data.id);
        $("#voornaam").val(data.voornaam);
        $("#achternaam").val(data.achternaam);
        $("#email").val(data.email);
        $("#telefoonnummer").val(data.telefoonnummer);
        $("#product").val(data.producten);
        $("#datum").val(data.einddatum);
      }
    });
  });
  //data updaten request
  $("#update").click(function(e) {
    if ($("#edit-form-data")[0].checkValidity()) {
      e.preventDefault();
      $.ajax({
        url: "action.php",
        type: "POST",
        data: $("#edit-form-data").serialize() + "&action=update",
        success: function(response) {
          console.log(response);
          toastr.success("Klant successvol aangepast");
          $("#editModal").modal("hide");
          $("#edit-form-data")[0].reset();
          showData();
        }
      });
    }
  });
  //verwijder request
  $("body").on("click", ".delBtn", function(e) {
    e.preventDefault();
    var tr = $(this).closest("tr");
    del_id = $(this).attr("id");
    Swal.fire({
      title: "Weet je het zeker?",
      text: "Je kan dit niet terug draaien!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Ja, Verwijder het!"
    }).then(result => {
      if (result.value) {
        $.ajax({
          url: "action.php",
          type: "POST",
          data: { del_id: del_id },
          success: function(response) {
            console.log(response);
            tr.css("background-color", "#ff0000");
            Swal.fire("Deleted", "Klant succesvol verwijderd", "success");
            showData();
          }
        });
      }
    });
  });

  //klant details request
  $("body").on("click", ".infoBtn", function(e) {
    e.preventDefault();
    info_id = $(this).attr("id");
    $.ajax({
      url: "action.php",
      type: "POST",
      data: { info_id: info_id },
      success: function(response) {
        //console.log(response);
        data = JSON.parse(response);
        Swal.fire({
          title: "<strong>ID(" + data.id + ")</strong>",
          type: "info",
          html:
            "<b>Voornaam : </b> " +
            data.voornaam +
            "<br><b>Achternaam : </b>" +
            data.achternaam +
            "<br><b>Email : </b>" +
            data.email +
            "<br><b>Eind datum : </b>" +
            data.einddatum
          // showCancelButton: true
        });
      }
    });
  });
  toastr.options = {
    closeButton: false,
    debug: false,
    newestOnTop: false,
    progressBar: true,
    positionClass: "toast-top-right",
    preventDuplicates: false,
    onclick: null,
    showDuration: "500",
    hideDuration: "1000",
    timeOut: "5000",
    extendedTimeOut: "1000",
    showEasing: "swing",
    hideEasing: "linear",
    showMethod: "fadeIn",
    hideMethod: "fadeOut"
  };
});
