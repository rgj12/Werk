<?php
if (!$_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION["response"] = "Er is iets misgegaan!";
    $_SESSION["res_type"] = "danger";
    header("location: register.php");
    exit();
} else {
    session_start();
    require_once 'config.php';
    $db = new Database();

    if (isset($_POST["submit"])) {
        if (empty($_POST["username"]) || empty($_POST["password"]) || empty($_POST["email"])) {
            $_SESSION["response"] = "Vul alle velden in!";
            $_SESSION["res_type"] = "danger";
            header("location: register.php");
            exit();
        }
        $username = trim(htmlspecialchars($_POST['username']));
        $email = trim(htmlspecialchars($_POST['email']));
        $password = $_POST['password'];

        if (!preg_match("/^[a-zA-Z ]*$/", $username)) {
            $_SESSION["response"] = "Only letters and white space allowed";
            $_SESSION["res_type"] = "danger";
            header("location: register.php");
            exit();
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION["response"] = "Er is iets misgegaan";
            $_SESSION["res_type"] = "danger";
            header("location: register.php");
            exit();
        } elseif (!preg_match("/^[a-zA-Z ]*$/", $password)) {
            $_SESSION["response"] = "Only letters and white space allowed";
            $_SESSION["res_type"] = "danger";
            header("location: register.php");

        } else {
            if ($db->checkUsername($username) > 0) {
                $_SESSION["response"] = "Gebruikersnaam bestaat al!";
                $_SESSION["res_type"] = "danger";
                header("location: register.php");
                exit();
            } else {
                $db->insertUser($username, $email, $password);
                $_SESSION["response"] = "Gebruiker aangemaakt";
                $_SESSION["res_type"] = "success";
                header("location: register.php");

            }

        }

    } else {
        $_SESSION["response"] = "Er is iets misgegaan";
        $_SESSION["res_type"] = "danger";
        header("location: register.php");
    }

}