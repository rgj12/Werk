<?php
class Database
{
    private $dsn = "mysql:host=localhost;dbname=antivirus";
    private $user = "root";
    private $password = "";
    public $conn;

    public function __construct()
    {
        try {
            $this->conn = new PDO($this->dsn, $this->user, $this->password);
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }
    public function getUserCount($username, $password)
    {
        $query = "SELECT * FROM users WHERE username = :username AND password = :password";
        $stmt = $this->conn->prepare($query);
        $stmt->execute(['username' => $username, 'password' => $password]);
        $totalRows = $stmt->rowCount();
        return $totalRows;
    }
    public function getUser($username)
    {
        $data = array();
        $query = "SELECT * FROM users WHERE username = :username";
        $stmt = $this->conn->prepare($query);
        $stmt->execute(['username' => $username]);
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($result as $row) {
            $data[] = $row;
        }
        return $data;
    }

    public function getRowCount()
    {
        $query = "SELECT * FROM users";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $totalRows = $stmt->rowCount();
        return $totalRows;
    }

    public function getSingle($id)
    {
        $query = "SELECT * FROM users WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute(['id' => $id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }
    public function checkUsername($username)
    {
        $query = "SELECT * FROM users WHERE username = :username";
        $stmt = $this->conn->prepare($query);
        $stmt->execute(['username' => $username]);
        $totalRows = $stmt->rowCount();
        return $totalRows;
    }
    public function insertUser($username, $email, $password)
    {
        $hashedpwd = password_hash($password, PASSWORD_DEFAULT);
        $query = "INSERT INTO users (username,email,password)
        VALUES(:username,:email,:password)";

        $stmt = $this->conn->prepare($query);
        $stmt->execute(['username' => $username, 'email' => $email, 'password' => $hashedpwd]);
        return true;
    }
}