<?php
if (!$_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION["response"] = "Er is iets misgegaan!";
    $_SESSION["res_type"] = "danger";
    header("location:login.php");
    exit();
} else {
    session_start();
    $_SESSION['loggedIn'] = false;
    require_once 'config.php';
    $db = new Database();

    if (isset($_POST["submit"])) {
        if (empty($_POST["username"]) || empty($_POST["password"])) {
            $_SESSION["response"] = "Vul alle velden in!";
            $_SESSION["res_type"] = "danger";
            header("location:login.php");
            exit();
        }
        $username = trim(htmlspecialchars($_POST['username']));
        $password = $_POST['password'];
        $data = $db->getUser($username);
        foreach ($data as $row) {
            $username = $row['username'];
            $hashedpwd = $row['password'];
        }

        if (password_verify($password, $hashedpwd)) {
            $_SESSION['username'] = $username;
            $_SESSION['loggedIn'] = true;

            header("location: ../index.php");
        } else {
            $_SESSION["response"] = "Onjuiste login!";
            $_SESSION["res_type"] = "danger";
            header("location:login.php");
        }

    } else {
        $_SESSION["response"] = "Er is iets misgegaan";
        $_SESSION["res_type"] = "danger";
        header("location: login.php");
        exit();
    }

}