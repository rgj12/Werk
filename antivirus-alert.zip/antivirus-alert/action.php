<?php
require_once "config.php";
$db = new Database();

//laat data zien
if (isset($_POST['action']) && $_POST['action'] == 'view') {
    $output = '';
    $data = $db->read();

    if ($db->getRowCount() > 0) {
        $output .= ' <table class="table table-striped table-sm table-bordered">
        <thead>
            <tr class="text-center">
                <th>ID</th>
                <th>Voornaam</th>
                <th>Achternaam</th>
                <th>Email</th>
                <th>telefoon</th>
                <th>Producten</th>
                <th>Einde antivirus</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>';
        foreach ($data as $row) {
            $output .= '<tr class="text-center text-secondary">
            <td>' . $row['id'] . '</td>
            <td>' . $row['voornaam'] . '</td>
            <td>' . $row['achternaam'] . '</td>
            <td>' . $row['email'] . '</td>
            <td>' . $row['telefoonnummer'] . '</td>
            <td>' . $row['producten'] . '</td>
            <td>' . $db->calcTimeLeft($row['einddatum'], $row['id']) . '</td>
            <td>
            <a href="#" title="Bekijk details" class="text-success infoBtn" id="' . $row["id"] . '"><i
                    class="fas fa-info-circle fa-lg"></i></a>&nbsp;&nbsp;
            <a href="#" title="Bewerk klant" class="text-warning editBtn" data-toggle="modal" data-target="#editModal" id="' . $row["id"] . '"><i
                    class="fas fa-edit fa-lg"></i></a>&nbsp;&nbsp;
            <a href="#" title="Verwijder klant" class="text-danger delBtn" id="' . $row["id"] . '"><i
                    class="fas fa-trash-alt fa-lg"></i></a>&nbsp;&nbsp;
        </td></tr>';
            //mailen
            $to = "administratie@it-skills.nl";
            $subject = " Er zijn klanten met bijna verlopen antivirus";
            $headers = 'From:renatogomes600@gmail.com' . "\r\n" .
            'Reply-To: renatogomes600@gmail.com' . "\r\n" .
            'Content-Type: text/html; charset=ISO-8859-1\r\n' .
            'X-Mailer: PHP/' . phpversion();
            $message = " De volgende klant heeft nog 1 maand antivirus" . "<br><br>
            <b>NAAM</b> : " . $row['voornaam'] . "  " . $row['achternaam'] . "<br>
            <b>EMAIL</b>:" .
                $row['email'] . "<br>
            <b>TEL</b> : " . $row['telefoonnummer'] . "<br>
            <b>PRODUCTEN</b> : " . $row['producten'];

            $message2 = "De volgende klant heeft nog minder dan 30 dagen antivirus" . "
                <b>NAAM</b>: " . $row['voornaam'] . "  " . $row['achternaam'] . "
                <b>EMAIL</b>:" .
                $row['email'] . "
                <b>TEL</b> : " . $row['telefoonnummer'] . "
                <b>PRODUCTEN</b> : " . $row['producten'];
            $mailed = true;

            if ($row['jaren_over'] == 0 && $row['maanden_over'] == 1 && $row['dagen_over'] == 5 && $row['mailed'] == false) {
                if (mail($to, $subject, $message, $headers)) {
                    $db->setMailed($row['id'], $mailed);

                }
            } elseif ($row['jaren_over'] == 0 && $row['maanden_over'] == 0 && $row['dagen_over'] > 30 && $row['mailed'] == false) {
                if (mail($to, $subject, $message2, $headers)) {
                    $db->setMailed($row['id'], $mailed);

                }
            }
        }
        $output .= '</tbody></table>';
        echo $output;
    } else {
        echo '<h3 class="text-center text-secondary mt-5">Geen gebruikers beschikbaar</h3>';
    }
}
//data toevoegen aan db
if (isset($_POST['action']) && $_POST['action'] == "toevoegen") {
    $vnaam = $_POST['voornaam'];
    $anaam = $_POST['achternaam'];
    $email = $_POST['email'];
    $tel = $_POST['telefoonnummer'];
    $product = $_POST['producten'];
    $einddatum = $_POST['datum'];

    $db->add($vnaam, $anaam, $email, $tel, $product, $einddatum);
}

//data naar form met json versturen
if (isset($_POST['edit_id'])) {
    $id = $_POST['edit_id'];
    $row = $db->getSingle($id);
    echo json_encode($row);
}
//data updaten in db
if (isset($_POST['action']) && $_POST['action'] == "update") {
    $id = $_POST['id'];
    $vnaam = $_POST['voornaam'];
    $anaam = $_POST['achternaam'];
    $email = $_POST['email'];
    $tel = $_POST['telefoonnummer'];
    $product = $_POST['product'];
    $einddatum = $_POST['datum'];

    $db->update($vnaam, $anaam, $email, $tel, $product, $einddatum, $id);
}

//verwijder
if (isset($_POST['del_id'])) {
    $id = $_POST['del_id'];
    $db->delete($id);
}

//details
if (isset($_POST["info_id"])) {
    $id = $_POST["info_id"];
    $row = $db->getSingle($id);
    echo json_encode($row);
}
//exporteer naar excel
if (isset($_GET['export']) && $_GET['export'] == 'excel') {
    header("Content-Type: application/xls");
    header("Content-Disposition: attachment; filename=klanten.xls");
    header("Pragma:nocache");
    header("Expires: 0");

    $data = $db->read();
    echo '<table border="1">';
    echo '<tr><th>ID</th><th>Voornaam</th><th>Achternaam</th><th>Email</th><th>Telefoonnummer</th><th>Product</th><th>Einddatum</th></tr>';

    foreach ($data as $row) {
        echo '<tr>
        <td>' . $row['id'] . '</td>
        <td>' . $row['voornaam'] . '</td>
        <td>' . $row['achternaam'] . '</td>
        <td>' . $row['email'] . '</td>
        <td>' . $row['telefoonnummer'] . '</td>
        <td>' . $row['producten'] . '</td>
        <td>' . $row['einddatum'] . '</td>

        </tr>';
    }
    echo '</table>';
}