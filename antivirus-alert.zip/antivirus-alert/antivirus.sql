-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 06 mrt 2020 om 10:14
-- Serverversie: 10.4.8-MariaDB
-- PHP-versie: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `antivirus`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `klanten`
--

CREATE TABLE `klanten` (
  `id` int(11) NOT NULL,
  `voornaam` varchar(255) NOT NULL,
  `achternaam` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefoonnummer` varchar(255) NOT NULL,
  `producten` varchar(11) NOT NULL,
  `einddatum` varchar(255) NOT NULL,
  `jaren_over` varchar(255) NOT NULL,
  `maanden_over` varchar(255) NOT NULL,
  `dagen_over` varchar(255) NOT NULL,
  `mailed` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `klanten`
--

INSERT INTO `klanten` (`id`, `voornaam`, `achternaam`, `email`, `telefoonnummer`, `producten`, `einddatum`, `jaren_over`, `maanden_over`, `dagen_over`, `mailed`) VALUES
(1, 'Dick', 'Vergoes Houwens', 'dvergoes@caiway.nl', '0611765257', '1 pc 1jr', '2020-01-29', '0', '1', '6', 0),
(2, 'Banketbakkerij', 'Maris', 'info@koekjesvanmaris.nl', 'n.v.t', '3 pc\'s 1jr', '2020-01-29', '0', '1', '6', 0),
(3, 'A.H', 'Ekker', 'a.ekker@online.nl', '0105012051', '1 pc 1jr', '2020-02-12', '0', '0', '22', 1),
(4, 'Herma', 'Davids', 'hermadavids@gmail.com', '0622118698', '1 pc 1jr', '2020-02-12', '0', '0', '22', 1),
(5, 'Jan', 'Verheij', 'jan.verheij@kabelfoon.nl', '0105012251', '3 pc\'s 1jr', '2020-02-21', '0', '0', '13', 1),
(6, 'Caroline', 'van Keulen', 'mulder3054@kpnmail.nl', '0102161969', '1 pc 1jr', '2020-02-28', '0', '0', '6', 0),
(7, 'Patries', 'Bijholt', 'patriesbijholt@live.nl', '0627553372', '1 pc 1jr', '2020-03-07', '0', '0', '2', 0),
(8, 'Martha', 'Marre', 'jaan01@hotmail.com', '0651181204', '1 pc 1jr', '2020-03-14', '0', '0', '9', 0),
(9, 'T.W', 'Waarneming', 'hpfvantwesteinde@gmail.com', '0641055184', '1 pc 1jr', '2020-03-26', '0', '0', '21', 0),
(10, 'Coen', 'Hendricks Vastgoed B.V', 'niet beschikbaar', '0621531479', '1pc 1jr', '2020-04-02', '0', '0', '27', 0),
(11, 'Schildersbedrijf', 'H van Steijbos', 'hvanstrijbos@versatel.nl', '0653840512', '1pc 1jr', '2020-04-09', '0', '1', '4', 0),
(12, 'Elody', 'Hogerwerf', 'mv.hogerwerf@hotmail.com', '0651125276', '1pc 1jr', '2020-04-09', '0', '1', '4', 0),
(13, 'Ineke', 'de Klerk', 'kedeklerk@planet.nl', '0623170201', '1pc 1jr', '2020-04-11', '0', '1', '6', 0),
(14, 'Carola', 'de Koning', 'mail@caroladekoning.nl', '0652544797', '1 pc 1jr', '2020-04-28', '0', '1', '23', 0),
(15, 'B.', 'van Damme', 'basicway@zeelandnet.nl', '0612329571', '1PC 1jr', '2020-05-09', '0', '2', '4', 0),
(16, 'Giddy', 'Wolf', 'gid.wolff@kpnmail.nl', '181283619', '1pc 1jr', '2020-05-09', '0', '2', '4', 0),
(17, 'Nicole ', 'Verbrugge', 'nicoleverbrugge123@gmail.com', '0647924948', '1pc 1jr', '2020-05-14', '0', '2', '9', 0),
(18, 'Maasvuur', 'n.v.t', 'wrieken@planet.nl', '0102810021', '1pc 1jr', '2020-05-17', '0', '2', '12', 0),
(19, 'Stichting Dreamnight', 'At The Zoo', 'info@dreamnightatthezoo.nl', '0624227667', '4pc\'s 1jr', '2020-05-17', '0', '2', '12', 0),
(20, 'Gall & Gall', 'n.v.t', 'robderaadt@yahoo.com', '0703931414', '1 pc 1jr', '2020-05-28', '0', '2', '23', 0),
(21, 'Bianca ', 'Todd', 'bianca_todd@hotmail.com', '0622703745', '1pc 1jr', '2020-05-31', '0', '2', '26', 0),
(22, 'John', 'Bruning', 'johnbr@caiway.nl', '0105013022', '1pc 1jr', '2020-06-13', '0', '3', '9', 0),
(23, 'Transpro Executive', 'n.v.t', 'info@transpro-executive.com', '0634860368', '1pc 1jr', '2020-06-18', '0', '3', '14', 0),
(24, 'Sunny Side Water Management', 'n.v.t', 'edh.sunnyside@gmail.com', '0651607369', '2 pc\'s 1jr', '2020-07-26', '0', '4', '22', 0),
(25, 'Bella', 'Derma', 'info@belladerma.nl', '0641296916', '1pc 1jr', '2020-08-06', '0', '5', '3', 0),
(26, 'HBB Bouwbegeleiding', 'n.v.t', 'hbb@xs4all.nl', '0654315263', '1pc 1jr', '2020-09-06', '0', '6', '4', 0),
(27, 'J.E', 'de Bruin', 'hans79@caiway.nl', '0612413568', '3 pc\'s 1jr', '2020-09-26', '0', '6', '24', 0),
(28, 'Annelies', 'Mac Pherson', 'amac@telfort.nl', '0105015744', '1pc 1jr', '2020-09-27', '0', '6', '25', 0),
(29, 'Brusselslof', 'n.v.t', 'info@brussels-lof.nl', '0643975062', '3 pc\'s 1jr', '2020-09-27', '0', '6', '25', 0),
(30, 'Coen', 'van Alphen', 'cdvanalphen@hotmail.com', '0628128220', '1 pc 1jr', '2020-10-11', '0', '7', '9', 0),
(31, 'R.', 'Petie', 'r.petie@kpnplanet.nl', '0105015382', '1 pc 1jr', '2020-10-18', '0', '7', '16', 0),
(32, 'Preparateur Schouten', 'n.v.t', 'preparateur.schouten@gmail.com', '0633608244', '1pc 1jr', '2020-10-23', '0', '7', '21', 0),
(33, 'C.', 'Duinhouwer', 'c.duinhouwer@gmail.com', '0105016093', '1pc 1jr', '2020-10-23', '0', '7', '21', 0),
(34, 'Paul', 'Groenenboom', 'janw.groenenboom@gmail.com', '0105013222', '1pc 1jr', '2020-11-21', '0', '8', '21', 0),
(35, 'Andre ', 'Niessen', 'aniessen@online.nl', '0650819212', '2pc\'s 1jr', '2020-11-29', '0', '8', '29', 0),
(36, 'M.A', 'Visser', 'devissermariek@hotmail.com', '0629002359', '1pc 1jr', '2020-11-29', '0', '8', '29', 0);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(9, 'itskillsnl', 'info@it-skills.nl', '$2y$10$ptvSM3Ny3kSxl42QudYJ7ewxYv/Y9jD4fxaANgN.Pki3oJTAR7lIe'),
(10, 'renato', 'administratie@it-skills.nl', '$2y$10$uRz6iPN3.AqOgr6BHmI1oeTW2mDH/uXwVHqz9spXqK.V..qRsEKa2');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `klanten`
--
ALTER TABLE `klanten`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `klanten`
--
ALTER TABLE `klanten`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT voor een tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
