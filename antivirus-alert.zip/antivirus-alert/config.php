<?php
class Database
{
    private $dsn = "mysql:host=localhost;dbname=antivirus";
    private $user = "root";
    private $password = "";
    public $conn;

    public function __construct()
    {
        try {
            $this->conn = new PDO($this->dsn, $this->user, $this->password);
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    public function add($vnaam, $anaam, $email, $telefoon, $product, $einddatum)
    {
        $query = "INSERT INTO klanten (voornaam,achternaam,email,telefoonnummer,producten,einddatum)
        VALUES(:vnaam,:anaam,:email,:telefoon,:product,:einddatum)";

        $stmt = $this->conn->prepare($query);
        $stmt->execute(['vnaam' => $vnaam, 'anaam' => $anaam, 'email' => $email, 'telefoon' => $telefoon, 'product' => $product, 'einddatum' => $einddatum]);
        return true;
    }

    public function read()
    {
        $data = array();
        $query = "SELECT * FROM klanten";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($result as $row) {
            $data[] = $row;
        }
        return $data;
    }

    public function update($vnaam, $anaam, $email, $tel, $product, $einddatum, $id)
    {
        $query = "UPDATE klanten SET voornaam = :vnaam, achternaam = :anaam, email = :email,
        telefoonnummer = :tel, producten = :product, einddatum = :einddatum WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute(['vnaam' => $vnaam, 'anaam' => $anaam, 'email' => $email, 'tel' => $tel, 'product' => $product, 'einddatum' => $einddatum, 'id' => $id]);
        return true;
    }
    public function delete($id)
    {
        $query = "DELETE FROM klanten WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute(['id' => $id]);
        return true;
    }

    public function getRowCount()
    {
        $query = "SELECT * FROM klanten";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $totalRows = $stmt->rowCount();
        return $totalRows;
    }

    public function getSingle($id)
    {
        $query = "SELECT * FROM klanten WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute(['id' => $id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }
    public function setMailed($id, $mailed)
    {
        $query = "UPDATE klanten SET  mailed = :mailed WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute(['mailed' => $mailed, 'id' => $id]);
        return true;
    }

    public function calcTimeLeft($date, $id)
    {
        $date1 = $date;
        $date2 = date("Y-m-d");

        $diff = abs(strtotime($date2) - strtotime($date1));

        $years = floor($diff / (365 * 60 * 60 * 24));
        $months = floor(($diff - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
        $days = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24) / (60 * 60 * 24));

        //printf("%d years, %d months, %d days\n", $years, $months, $days);
        $query = "UPDATE klanten SET jaren_over = :jaren_over, maanden_over = :maanden_over , dagen_over = :dagen_over WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute(['jaren_over' => $years, 'maanden_over' => $months, 'dagen_over' => $days, 'id' => $id]);

        $date = new DateTime($date1);
        $now = new DateTime();

        if ($date < $now) {
            return "<p class='badge badge-danger'>VERLOPEN<p/>";
        }

        if ($years == 0 && $months == 1 && $days == 0) {
            return $months . " maanden over";
        } elseif ($years == 0 && $months == 0 && $days <= 30) {
            return "<p class='badge badge-warning'>Minder dan 30 dagen over<p/>";
        } elseif ($years == 0 && $months == 0 && $days == 0) {
            return "<p class='badge badge-danger'>VERLOPEN<p/>";
        } else {
            return $years . " jaar " . $months . " maanden " . $days . " dagen ";
        }
    }
}
//$db = new Database();
//echo $db->getRowCount();