<?php
session_start();
if (!isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] !== true) {
    header("location: loginsystem/login.php");
    exit();
} else {

    ?>
<!doctype html>
<html lang="en">

<head>
    <title>Antivirussoftware,hosting,SSL & Domeinregistratie</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- <meta http-equiv="refresh" content="30"> -->

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.20/datatables.min.css" />
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" />
</head>

<body>
    <nav class="navbar navbar-expand-md bg-dark navbar-dark">
        <!-- Brand -->
        <a class="navbar-brand" href="#"><i class="fas fa-radiation"></i> Antivirussoftware & hosting</a>

        <!-- Toggler/collapsibe Button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navbar links -->
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
                <div class="dropdown">
                    <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-user"></i>&nbsp;&nbsp;<?=$_SESSION['username'];?>
                    </a>

                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                        <!-- <a class="dropdown-item" href="#"><i class="fas fa-user-alt"></i>&nbsp;&nbsp;Profiel</a> -->
                        <!-- <a class="dropdown-item" href="#">Another action</a> -->
                        <a class="dropdown-item" href="loginsystem/loguit.php"><i
                                class="fas fa-sign-out-alt"></i>&nbsp;&nbsp;Log uit</a>
                    </div>
                </div>
                <!-- <li class="nav-item">
                    <a class="nav-link" href="#">Link</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Link</a>
                </li> -->
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h4 class="text-center text-danger font-weight-normal my-3">Antivirussoftware,hosting,SSL &
                    Domeinregistratie</h4>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <h4 class="mt-2 text-primary">
                    KLANTEN
                </h4>
            </div>
            <div class="lg-col-6">
                <button class="btn btn-primary m-1 float-right" data-toggle="modal" data-target="#toevoegModal"><i
                        class="fas fa-user-plus fa-lg"></i>&nbsp;&nbsp;Voeg
                    klant
                    toe</button>
                <a href="action.php?export=excel" class="btn btn-success m-1 float-right"><i
                        class="fas fa-table fa-lg"></i>&nbsp;&nbsp;Export
                    naar
                    Excel</a>
            </div>
        </div>
        <hr class="my-1">
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive" id="showCustomers">
                    <h3 class="text-center text-success" style="margin-top:15px;">Laden...</h3>


                </div>
            </div>
        </div>
    </div>
    <!-- Toevoeg Modal-->
    <div class="modal fade" id="toevoegModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Voeg klant toe</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body px-4">
                    <form action="#" id="form-data" method="post">
                        <div class="form-group">
                            <input type="text" name="voornaam" id="" class="form-control" placeholder="Voornaam"
                                required>
                        </div>
                        <div class="form-group">
                            <input type="text" name="achternaam" id="" class="form-control" placeholder="Achternaam"
                                required>
                        </div>
                        <div class="form-group">
                            <input type="email" name="email" id="" class="form-control" placeholder="Email" required>
                        </div>
                        <div class="form-group">
                            <input type="text" name="telefoonnummer" id="" class="form-control"
                                placeholder="telefoon nummer" required>
                        </div>
                        <div class="form-group">
                            <input type="text" name="producten" id="" class="form-control" placeholder="Producten"
                                required>
                        </div>
                        <div class="form-group">
                            <input type="date" name="datum" id="" class="form-control" placeholder="Datum" required>
                        </div>
                        <div class="form-group">
                            <input type="submit" name="toevoegen" id="toevoegen" class="btn btn-success btn-block"
                                value="Verzend gegevens">
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>

    <!-- Edit Modal-->
    <div class="modal fade" id="editModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header  text-center">
                    <h4 class="modal-title">bewerk klant</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body px-4">
                    <form action="#" id="edit-form-data" method="post">
                        <input type="hidden" name="id" id="id">
                        <div class="form-group">
                            <input type="text" name="voornaam" id="voornaam" class="form-control">
                        </div>
                        <div class="form-group">
                            <input type="text" name="achternaam" id="achternaam" class="form-control">
                        </div>
                        <div class="form-group">
                            <input type="email" name="email" id="email" class="form-control">
                        </div>
                        <div class="form-group">
                            <input type="text" name="telefoonnummer" id="telefoonnummer" class="form-control">
                        </div>
                        <div class="form-group">
                            <input type="text" name="product" id="product" class="form-control">
                        </div>
                        <div class="form-group">
                            <input type="date" name="datum" id="datum" class="form-control">
                        </div>
                        <div class="form-group">
                            <input type="submit" name="update" id="update" class="btn btn-warning btn-block"
                                value="pas aan">
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.20/datatables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <script src="https:cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

    <script src="js/request.js"></script>
    <script src="js/autorefresh.js"></script>

</body>

</html>
<?php
}
?>